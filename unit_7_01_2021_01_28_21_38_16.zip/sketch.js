let img;

function preload() {
  img = loadImage('cute-letter.png')
}

function setup() {
  createCanvas(560, 450);
}

function draw() {
  background(252, 3, 98); //r,g,b
  image(img, 0, 0, 555, 450)
  // Draw a square with rounded corners, each having a radius of 20.
  square(250, 250, 60, 50);
  fill(250, 100, 100);

}